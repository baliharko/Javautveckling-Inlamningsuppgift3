package Del_02;

/**
 * Inlamningsuppgift3
 * baliharko
 * 2020-09-15
 * 16:17
 */

/*
*********************************************************************
************************ GISSA ORDET-SPELET *************************
*********************************************************************
*                                                                   *
*               Gissa vilket ord som visas i terminalen:            *
*                                                                   *
*   - Varje ord har fått bokstäverna omkastade.                     *
*                                                                   *
*   - 10 frågor.                                                    *
*                                                                   *
*   - Ord med 3 eller färre bokstäver ger 1 poäng.                  *
*   - Ord med minst 4 bokstäver och under 6 bokstäver ger 2 poäng.  *
*   - Ord med 6 eller fler bokstäver ger 3 poäng.                   *
*                                                                   *
*                                                                   *
*                             LYCKA TILL!                           *
*                               //Bali                              *
* *******************************************************************
*/

public class Del_02_Main {
    public static void main(String[] args) {

        Menu.showMenu(); // Visar menyn i terminalen och startar spelet.

    }
}
